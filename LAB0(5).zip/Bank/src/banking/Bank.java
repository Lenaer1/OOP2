/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

/**
 *
 * @author User
 */
public interface Bank {
    public void deposit ();
    public void withdraw ();
    public float getbBalance();
}
