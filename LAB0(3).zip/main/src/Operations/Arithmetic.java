/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operations;

/**
 *
 * @author User
 */
public class Arithmetic {
    private int first_number;
    private int second_number;
    public Arithmetic () {
        first_number = 10;
        second_number = 5;
    }
   public int sum (){
       return  first_number + second_number;
       
   } 
   public int difference(){
       return  first_number - second_number;
   }
   public int product(){
       return first_number* second_number;
   }
   public int getfirst_number(){
       return first_number;
   }
   public int getsecond_number(){
       return second_number;
   }
}
