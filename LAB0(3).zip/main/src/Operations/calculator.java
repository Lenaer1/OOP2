/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operations;

/**
 *
 * @author User
 */
public class calculator extends Arithmetic {
    public int sub;
 @Override 
 public int difference (){
     if (getfirst_number()>getsecond_number()){
     sub = getfirst_number() - getsecond_number();
    return (getfirst_number()-getsecond_number());        
 }
     return 0;
}
}